#ifndef fakeit_h__
#define fakeit_h__

#include "fakeit_instance.hpp"
#include "fakeit/fakeit_root.hpp"

#endif